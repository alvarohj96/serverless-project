import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='alvarohj96',
    application_name='api-rest-app',
    app_uid='xMVGDjhhbn3sCf6fPT',
    org_uid='0efc6298-dc05-44b9-93ab-959165ee5616',
    deployment_uid='9a93b0a2-490d-4981-a4fb-d4398cb984bc',
    service_name='api-rest',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='Release',
    plugin_version='5.0.0',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'api-rest-Release-delete', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('todos/delete.delete')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
